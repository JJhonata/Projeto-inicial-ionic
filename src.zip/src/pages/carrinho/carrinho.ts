import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-carrinho',
  templateUrl: 'carrinho.html'
})
export class CarrinhoPage {
  itens: Array<{nome: string, quantidade: number, preco: number}> = [
    { nome: 'Quem é você alaska', quantidade: 2, preco: 29.90 },
    { nome: 'Você ligou para o sam', quantidade: 1, preco: 49.90 }
  ];

  constructor(public navCtrl: NavController) {}

  calcularTotal() {
    return this.itens.reduce((total, item) => total + (item.quantidade * item.preco), 0);
  }
}

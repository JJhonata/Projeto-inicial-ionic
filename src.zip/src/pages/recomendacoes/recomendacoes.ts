import { Component } from '@angular/core';

@Component({
  selector: 'page-recomendacoes',
  templateUrl: 'recomendacoes.html'
})
export class RecomendacoesPage {
  livrosRecomendados: Array<{ titulo: string, autor: string, descricao: string }> = [
    { titulo: 'O Alquimista', autor: 'Paulo Coelho', descricao: 'Uma jornada de autoconhecimento e aventura.' },
    { titulo: '1984', autor: 'George Orwell', descricao: 'Uma visão distópica do futuro.' },
    { titulo: 'Dom Casmurro', autor: 'Machado de Assis', descricao: 'Um romance clássico da literatura brasileira.' }
  ];

  constructor() {}
}

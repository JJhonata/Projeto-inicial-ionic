import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';

@Component({
  selector: 'page-list',
  templateUrl: 'list.html'
})
export class ListPage {
  generos: Array<{ nome: string, livros: Array<{ titulo: string, autor: string }> }> = [
    {
      nome: 'Ficção',
      livros: [
        { titulo: 'O Hobbit', autor: 'J.R.R. Tolkien' },
        { titulo: '1984', autor: 'George Orwell' },
        { titulo: 'Neuromancer', autor: 'William Gibson' },
        { titulo: 'Duna', autor: 'Frank Herbert' }
      ]
    },
    {
      nome: 'Não-Ficção',
      livros: [
        { titulo: 'Sapiens', autor: 'Yuval Noah Harari' },
        { titulo: 'O Gene', autor: 'Siddhartha Mukherjee' },
        { titulo: 'A Arte da Guerra', autor: 'Sun Tzu' },
        { titulo: 'O Poder do Hábito', autor: 'Charles Duhigg' }
      ]
    },
    {
      nome: 'Fantasia',
      livros: [
        { titulo: 'Harry Potter e a Pedra Filosofal', autor: 'J.K. Rowling' },
        { titulo: 'As Crônicas de Nárnia', autor: 'C.S. Lewis' },
        { titulo: 'O Nome do Vento', autor: 'Patrick Rothfuss' },
        { titulo: 'Mistborn: O Império Final', autor: 'Brandon Sanderson' }
      ]
    },
    {
      nome: 'Mistério',
      livros: [
        { titulo: 'O Assassinato de Roger Ackroyd', autor: 'Agatha Christie' },
        { titulo: 'O Silêncio dos Inocentes', autor: 'Thomas Harris' },
        { titulo: 'Sherlock Holmes: Um Estudo em Vermelho', autor: 'Arthur Conan Doyle' },
        { titulo: 'A Garota no Trem', autor: 'Paula Hawkins' }
      ]
    },
    {
      nome: 'Romance',
      livros: [
        { titulo: 'Orgulho e Preconceito', autor: 'Jane Austen' },
        { titulo: 'A Culpa é das Estrelas', autor: 'John Green' },
        { titulo: 'Como Eu Era Antes de Você', autor: 'Jojo Moyes' },
        { titulo: 'O Sol é para Todos', autor: 'Harper Lee' }
      ]
    },
    {
      nome: 'História',
      livros: [
        { titulo: 'Guns, Germs, and Steel', autor: 'Jared Diamond' },
        { titulo: 'História do Mundo em 100 Objetos', autor: 'Neil MacGregor' },
        { titulo: 'A Segunda Guerra Mundial', autor: 'Antony Beevor' },
        { titulo: 'O Mundo de Ontem', autor: 'Stefan Zweig' }
      ]
    },
    {
      nome: 'Biografia',
      livros: [
        { titulo: 'Steve Jobs', autor: 'Walter Isaacson' },
        { titulo: 'O Diário de Anne Frank', autor: 'Anne Frank' },
        { titulo: 'Minha Luta', autor: 'Adolf Hitler' },
        { titulo: 'Longa Caminhada até a Liberdade', autor: 'Nelson Mandela' }
      ]
    }
  ];

  livros: Array<{ titulo: string, autor: string }> = [];
  selectedGenero: string = '';

  constructor(public navCtrl: NavController, public navParams: NavParams) {}

  filtrarLivros(genero: string) {
    const generoSelecionado = this.generos.find(g => g.nome === genero);
    this.livros = generoSelecionado ? generoSelecionado.livros : [];
    this.selectedGenero = genero;
  }

  itemTapped(event, livro) {
    console.log('Livro selecionado:', livro);
  }
}

import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-avaliacoes',
  templateUrl: 'avaliacoes.html'
})
export class AvaliacoesPage {
  avaliacoes: Array<{livro: string, nota: number, comentario: string}> = [
    { livro: 'Quem é você alaska', nota: 10, comentario: 'O melhor que já li.' },
    { livro: 'Você ligou para o sam', nota: 10, comentario: 'Show de bola' }
  ];

  constructor(public navCtrl: NavController) {}
}

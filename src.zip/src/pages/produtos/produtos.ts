import { Component } from '@angular/core';
import { NavController, AlertController } from 'ionic-angular';

@Component({
  selector: 'page-produtos',
  templateUrl: 'produtos.html'
})
export class ProdutosPage {
  produtos: Array<{id: number, nome: string, descricao: string}> = [];

  constructor(public navCtrl: NavController, public alertCtrl: AlertController) {}

  adicionarLivro() {
    let prompt = this.alertCtrl.create({
      title: 'Adicionar Livro',
      inputs: [
        {
          name: 'nome',
          placeholder: 'Nome do Livro'
        },
        {
          name: 'descricao',
          placeholder: 'Descrição'
        }
      ],
      buttons: [
        {
          text: 'Cancelar',
          role: 'cancel'
        },
        {
          text: 'Salvar',
          handler: data => {
            const novoProduto = {
              id: this.produtos.length + 1,
              nome: data.nome,
              descricao: data.descricao
            };
            this.produtos.push(novoProduto);
          }
        }
      ]
    });
    prompt.present();
  }

  editarProduto(produto) {
    let prompt = this.alertCtrl.create({
      title: 'Editar Livro',
      inputs: [
        {
          name: 'nome',
          placeholder: 'Nome do Livro',
          value: produto.nome
        },
        {
          name: 'descricao',
          placeholder: 'Descrição',
          value: produto.descricao
        }
      ],
      buttons: [
        {
          text: 'Cancelar',
          role: 'cancel'
        },
        {
          text: 'Salvar',
          handler: data => {
            produto.nome = data.nome;
            produto.descricao = data.descricao;
          }
        }
      ]
    });
    prompt.present();
  }

  removerProduto(produto) {
    let confirm = this.alertCtrl.create({
      title: 'Remover Livro',
      message: `Deseja realmente remover o Livro "${produto.nome}"?`,
      buttons: [
        {
          text: 'Cancelar',
          role: 'cancel'
        },
        {
          text: 'Remover',
          handler: () => {
            const index = this.produtos.indexOf(produto);
            if (index > -1) {
              this.produtos.splice(index, 1);
            }
          }
        }
      ]
    });
    confirm.present();
  }
}

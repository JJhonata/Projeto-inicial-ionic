import { Component, ViewChild } from "@angular/core";
import { Platform, Nav, MenuController } from "ionic-angular";
import { StatusBar } from "@ionic-native/status-bar";
import { SplashScreen } from "@ionic-native/splash-screen";

import { HomePage } from "../pages/home/home";
import { ListPage } from "../pages/list/list";
import { RecomendacoesPage } from "../pages/recomendacoes/recomendacoes";
import { CarrinhoPage } from "../pages/carrinho/carrinho";
import { AvaliacoesPage } from "../pages/avaliacoes/avaliacoes";
import { ProdutosPage } from "../pages/produtos/produtos";

@Component({
  templateUrl: "app.html",
})
export class MyApp {
  @ViewChild(Nav) nav: Nav;

  rootPage: any = HomePage;

  pages: Array<{ title: string; component: any }>;

  constructor(
    platform: Platform,
    statusBar: StatusBar,
    splashScreen: SplashScreen,
    public menuCtrl: MenuController
  ) {
    platform.ready().then(() => {
      statusBar.styleDefault();
      splashScreen.hide();
    });

    this.pages = [
      { title: "Página Inicial", component: HomePage },
      { title: "Lista", component: ListPage },
      { title: "Recomendações", component: RecomendacoesPage },
      { title: "Carrinho", component: CarrinhoPage },
      { title: "Avaliações", component: AvaliacoesPage },
      { title: "Produtos", component: ProdutosPage },
    ];
  }

  openPage(page) {
    this.nav.setRoot(page.component);
    this.menuCtrl.close(); // Fecha o menu quando uma página é selecionada
  }
}
